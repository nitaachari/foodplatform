const Payment = require("../models/Payment");
const Order = require("../models/Order");
const Stripe = require("stripe");

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);




// ======================================
// Create Payment Attempt
// ======================================

const createPayment = async (
    orderId,
    userId,
    paymentMethod
) => {


    const order =
        await Order.findById(orderId);



    if (!order) {

        throw new Error(
            "Order not found."
        );

    }




    // Ensure only order owner can pay

    if (
        order.customer.toString()
        !== userId.toString()
    ) {

        throw new Error(
            "You are not authorized to pay for this order."
        );

    }




    // Prevent payment after successful payment

    if (
        order.paymentStatus === "paid"
    ) {

        throw new Error(
            "Order has already been paid."
        );

    }




    // Count previous payment attempts

    const previousAttempts =
        await Payment.countDocuments({

            order: orderId

        });




    // ======================================
    // Card payments go through Stripe.
    // Everything else (cod, upi, netbanking, wallet)
    // keeps the existing manual/mock flow for now.
    // ======================================

    let stripePaymentIntentId = null;
    let clientSecret = null;

    if (paymentMethod === "card") {

        // Stripe expects the amount in the smallest currency
        // unit — paise for INR.
        const amountInPaise = Math.round(order.pricing.total * 100);

        const intent = await stripe.paymentIntents.create(
            {
                amount: amountInPaise,
                currency: "inr",
                metadata: {
                    orderId: order._id.toString(),
                    userId: userId.toString()
                },
                automatic_payment_methods: {
                    enabled: true
                }
            },
            {
                // Prevents duplicate PaymentIntents if the client
                // retries this call for the same attempt.
                idempotencyKey: `order_${order._id}_attempt_${previousAttempts + 1}`
            }
        );

        stripePaymentIntentId = intent.id;
        clientSecret = intent.client_secret;

    }




    const payment =
        await Payment.create({

            order: order._id,
            user: userId,
            amount: order.pricing.total,
            paymentMethod,
            gateway: paymentMethod === "card" ? "stripe" : "mock",
            status: "pending",
            stripePaymentIntentId,

            attemptNumber:
                previousAttempts + 1

        });




    // clientSecret is single-use and only needed by the frontend
    // for this specific request — it is never persisted.
    return { payment, clientSecret };


};








// ======================================
// Verify Payment
// (manual flow — cod / non-Stripe methods only.
// Card payments are confirmed by the Stripe webhook,
// see markPaymentSucceeded / markPaymentFailed below,
// since a client can never be trusted to self-report
// that a real charge succeeded.)
// ======================================

const verifyPayment = async (

    paymentId,

    transactionId

) => {



    const payment =
        await Payment.findById(paymentId);




    if (!payment) {

        throw new Error(
            "Payment not found."
        );

    }



    if (
        payment.gateway === "stripe"
    ) {

        throw new Error(
            "Card payments are confirmed automatically by Stripe. Check the payment status instead of verifying manually."
        );

    }



    if (
        payment.status === "completed"
    ) {

        throw new Error(
            "Payment already completed."
        );

    }



    // Check if another attempt already succeeded

    const existingSuccessfulPayment =
        await Payment.findOne({

            order: payment.order,

            status:"completed"

        });



    if(existingSuccessfulPayment){

        throw new Error(
            "Order is already paid."
        );

    }



    payment.status = "completed";


    payment.transactionId =
        transactionId;
    payment.paidAt = new Date();


    payment.metadata = {

        verified:true

    };



    await payment.save();




    // Update order payment status

    const order =
        await Order.findById(
            payment.order
        );



    order.paymentStatus = "paid";


    order.payment =
        payment._id;



    await order.save();




    return payment;


};








// ======================================
// Get Payment By ID
// ======================================

const getPaymentById = async (

    paymentId,

    userId

) => {



    const payment =
        await Payment.findById(paymentId)
        .populate("order");





    if(!payment){

        throw new Error(
            "Payment not found."
        );

    }





    if(
        payment.user.toString()
        !== userId.toString()
    ){

        throw new Error(
            "Unauthorized."
        );

    }





    return payment;


};








// ======================================
// Get All Payments For Order
// ======================================

const getPaymentByOrderId = async (

    orderId,

    userId

) => {



    const payments =
        await Payment.find({

            order:orderId,

            user:userId

        })
        .sort({

            createdAt:-1

        });





    if(
        payments.length === 0
    ){

        throw new Error(
            "No payment attempts found."
        );

    }





    return payments;


};




// ======================================
// Mark Payment Succeeded
// (called from the Stripe webhook handler — this is the
// authoritative confirmation path for card payments, not
// anything the client submits directly)
// ======================================

const markPaymentSucceeded = async (

    stripePaymentIntentId

) => {

    const payment =
        await Payment.findOne({ stripePaymentIntentId });

    if (!payment) {

        // Webhook arrived for a PaymentIntent we don't recognize —
        // log and ignore rather than throwing, since Stripe will
        // retry on a non-2xx response.
        console.warn(
            `Stripe webhook: no Payment found for PaymentIntent ${stripePaymentIntentId}`
        );
        return null;

    }

    if (payment.status === "completed") {

        // Already processed (Stripe can send duplicate webhook
        // deliveries) — nothing further to do.
        return payment;

    }

    payment.status = "completed";
    payment.paidAt = new Date();
    payment.transactionId = stripePaymentIntentId;

    await payment.save();

    const order = await Order.findById(payment.order);

    if (order) {

        order.paymentStatus = "paid";
        order.payment = payment._id;

        await order.save();

        // TODO: once Socket.io is wired up (see sockets/index.js),
        // emit here so the customer's checkout page updates live:
        //
        // const { getIO } = require("../sockets");
        // getIO().to(`order:${order._id}`).emit("payment:completed", {
        //     orderId: order._id
        // });

    }

    return payment;

};




// ======================================
// Mark Payment Failed
// ======================================

const markPaymentFailed = async (

    stripePaymentIntentId

) => {

    const payment =
        await Payment.findOne({ stripePaymentIntentId });

    if (!payment) {

        console.warn(
            `Stripe webhook: no Payment found for PaymentIntent ${stripePaymentIntentId}`
        );
        return null;

    }

    if (payment.status !== "completed") {

        payment.status = "failed";
        await payment.save();

    }

    return payment;

};




module.exports = {


    createPayment,

    verifyPayment,

    getPaymentById,

    getPaymentByOrderId,

    markPaymentSucceeded,

    markPaymentFailed


};
