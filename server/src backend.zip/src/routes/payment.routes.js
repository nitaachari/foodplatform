const express = require("express");

const router = express.Router();

const {

    createPayment,

    verifyPayment,

    getPaymentById,

    getPaymentByOrderId

} = require("../controllers/payment.controller");

const protect=require("../middleware/auth.middleware");
const authorize=require("../middleware/role.middleware");


// ======================================
// Customer Routes
// ======================================

// Create Payment
router.post(

    "/create",

    protect,

    authorize("customer"),

    createPayment

);



// Verify Payment
router.post(

    "/verify",

    protect,

    authorize("customer"),

    verifyPayment

);



// Get Payment By Id
router.get(

    "/:id",

    protect,

    authorize("customer"),

    getPaymentById

);



// Get All Payment Attempts For Order
router.get(

    "/order/:orderId",

    protect,

    authorize("customer"),

    getPaymentByOrderId

);



module.exports = router;