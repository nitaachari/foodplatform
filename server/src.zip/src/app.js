const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const authRoutes = require("./routes/auth.routes");
const restaurantRoutes = require("./routes/restaurant.routes");
const categoryRoutes = require("./routes/category.routes");
const menuItemRoutes =require("./routes/menuItem.routes");
const cartRoutes =require("./routes/cart.routes");
const orderRoutes =require("./routes/order.routes");
const paymentRoutes = require("./routes/payment.routes");
const deliveryPartnerRoutes = require("./routes/deliveryPartner.routes");
const reviewRoutes = require("./routes/review.routes");
const app = express();


// Security Middleware

app.use(
    helmet()
);


// CORS

app.use(
    cors({
        origin:"http://localhost:5175",
        credentials:true
    })
);


// Body Parser

app.use(
    express.json()
);


app.use(
    express.urlencoded({
        extended:true
    })
);


// Cookies

app.use(
    cookieParser()
);


// Test Route

app.get(
    "/",
    (req,res)=>{

        res.json({
            message:"Food Ordering API Running"
        });

    }
);
app.use(
    "/api/auth",
    authRoutes
);
app.use("/api/restaurants", restaurantRoutes);
app.use(
    "/api/categories",
    categoryRoutes
);
app.use(
    "/api/menu",
    menuItemRoutes
);
app.use(
    "/api/cart",
    cartRoutes
);
app.use(
    "/api/orders",
    orderRoutes
);
app.use("/api/payments", paymentRoutes);
app.use(
    "/api/delivery-partners",
    deliveryPartnerRoutes
);

app.use(
    "/api/reviews",
    reviewRoutes
);



module.exports = app;