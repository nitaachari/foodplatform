const Payment = require("../models/Payment");
const Order = require("../models/Order");




// ======================================
// Create Payment Attempt
// ======================================

const createPayment = async (
    orderId,
    userId,
    paymentMethod
) => {


    const order =
        await Order.findById(orderId);



    if (!order) {

        throw new Error(
            "Order not found."
        );

    }




    // Ensure only order owner can pay

    if (
        order.customer.toString()
        !== userId.toString()
    ) {

        throw new Error(
            "You are not authorized to pay for this order."
        );

    }




    // Prevent payment after successful payment

    if (
        order.paymentStatus === "paid"
    ) {

        throw new Error(
            "Order has already been paid."
        );

    }





    // Count previous payment attempts

    const previousAttempts =
        await Payment.countDocuments({

            order: orderId

        });






    const payment =
        await Payment.create({

            order: order._id,

            user: userId,

            amount: order.pricing.total,

            paymentMethod,

            gateway: "mock",

            status: "pending",
            

            attemptNumber:
                previousAttempts + 1

        });





    return payment;


};







// ======================================
// Verify Payment
// ======================================

const verifyPayment = async (

    paymentId,

    transactionId

) => {



    const payment =
        await Payment.findById(paymentId);




    if (!payment) {

        throw new Error(
            "Payment not found."
        );

    }





    if (
        payment.status === "completed"
    ) {

        throw new Error(
            "Payment already completed."
        );

    }





    // Check if another attempt already succeeded

    const existingSuccessfulPayment =
        await Payment.findOne({

            order: payment.order,

            status:"completed"

        });





    if(existingSuccessfulPayment){

        throw new Error(
            "Order is already paid."
        );

    }





    payment.status = "completed";


    payment.transactionId =
        transactionId;
    payment.paidAt = new Date();


    payment.metadata = {

        verified:true

    };



    await payment.save();





    // Update order payment status

    const order =
        await Order.findById(
            payment.order
        );



    order.paymentStatus = "paid";


    order.payment =
        payment._id;



    await order.save();





    return payment;


};








// ======================================
// Get Payment By ID
// ======================================

const getPaymentById = async (

    paymentId,

    userId

) => {



    const payment =
        await Payment.findById(paymentId)
        .populate("order");





    if(!payment){

        throw new Error(
            "Payment not found."
        );

    }





    if(
        payment.user.toString()
        !== userId.toString()
    ){

        throw new Error(
            "Unauthorized."
        );

    }





    return payment;


};








// ======================================
// Get All Payments For Order
// ======================================

const getPaymentByOrderId = async (

    orderId,

    userId

) => {



    const payments =
        await Payment.find({

            order:orderId,

            user:userId

        })
        .sort({

            createdAt:-1

        });





    if(
        payments.length === 0
    ){

        throw new Error(
            "No payment attempts found."
        );

    }





    return payments;


};








module.exports = {


    createPayment,

    verifyPayment,

    getPaymentById,

    getPaymentByOrderId


};