const paymentService = require("../services/payment.service");



// ======================================
// Create Payment
// ======================================

const createPayment = async (req, res) => {

    try {

        const payment = await paymentService.createPayment(

            req.body.orderId,

            req.user._id,

            req.body.paymentMethod

        );

        res.status(201).json({

            success: true,

            message: "Payment created successfully.",

            payment

        });

    }
    catch (error) {

        res.status(400).json({

            success: false,

            message: error.message

        });

    }

};



// ======================================
// Verify Payment
// ======================================

const verifyPayment = async (req, res) => {

    try {

        const payment = await paymentService.verifyPayment(

            req.body.paymentId,

            req.body.transactionId

        );

        res.status(200).json({

            success: true,

            message: "Payment verified successfully.",

            payment

        });

    }
    catch (error) {

        res.status(400).json({

            success: false,

            message: error.message

        });

    }

};



// ======================================
// Get Payment By Id
// ======================================

const getPaymentById = async (req, res) => {

    try {

        const payment = await paymentService.getPaymentById(

            req.params.id,

            req.user._id

        );

        res.status(200).json({

            success: true,

            payment

        });

    }
    catch (error) {

        res.status(404).json({

            success: false,

            message: error.message

        });

    }

};



// ======================================
// Get Payments For Order
// ======================================

const getPaymentByOrderId = async (req, res) => {

    try {

        const payments = await paymentService.getPaymentByOrderId(

            req.params.orderId,

            req.user._id

        );

        res.status(200).json({

            success: true,

            payments

        });

    }
    catch (error) {

        res.status(404).json({

            success: false,

            message: error.message

        });

    }

};



module.exports = {

    createPayment,

    verifyPayment,

    getPaymentById,

    getPaymentByOrderId

};