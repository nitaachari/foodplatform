import api from "./axios";

// POST /api/payments/create  { orderId, paymentMethod }
export const createPaymentRequest = (orderId, paymentMethod) =>
  api
    .post("/payments/create", { orderId, paymentMethod })
    .then((res) => res.data);

// POST /api/payments/verify  { paymentId, transactionId }
export const verifyPaymentRequest = (paymentId, transactionId) =>
  api
    .post("/payments/verify", { paymentId, transactionId })
    .then((res) => res.data);
