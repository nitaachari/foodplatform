import api from "./axios";

// POST /api/orders  { deliveryAddress }
export const createOrderRequest = (deliveryAddress) =>
  api.post("/orders", { deliveryAddress }).then((res) => res.data);

// GET /api/orders/my
export const getMyOrdersRequest = () =>
  api.get("/orders/my").then((res) => res.data);

// GET /api/orders/:id
export const getOrderByIdRequest = (id) =>
  api.get(`/orders/${id}`).then((res) => res.data);

// PATCH /api/orders/:id/cancel  { reason }
export const cancelOrderRequest = (id, reason) =>
  api.patch(`/orders/${id}/cancel`, { reason }).then((res) => res.data);

// ---- Restaurant-owner endpoints ----

// GET /api/orders/restaurant (resolves the restaurant from the logged-in owner)
export const getRestaurantOrdersRequest = () =>
  api.get("/orders/restaurant").then((res) => res.data);

// PATCH /api/orders/:id/status  { status }
// Valid transitions (enforced server-side): placed -> accepted | rejected,
// accepted -> preparing, preparing -> ready. Anything past "ready" is handled
// by a delivery partner, not the restaurant.
export const updateOrderStatusRequest = (id, status) =>
  api.patch(`/orders/${id}/status`, { status }).then((res) => res.data);
